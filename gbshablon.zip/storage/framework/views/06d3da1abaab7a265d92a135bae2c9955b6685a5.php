
<?php $__env->startSection('title'); ?> Редактировать новость - ##parent-placeholder-3c6de1b7dd91465d437ef415f94f36afc1fbc8a8## <?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Редактировать новость </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
    </div>
  </div>

      <div class="table-responsive">
        <?php echo $__env->make('inc.message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <form  method="post" action="<?php echo e(route('admin.news.update',['news' => $news])); ?>">
          <?php echo csrf_field(); ?>
          <?php echo method_field('put'); ?>
          <div class="form-group">
            <label for="category_id">Категория</label>
            <select name="category_id" for="form-control" id="category_id">
              <option value="0">Нет категории</option>
              <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <option <?php if($category->id === $news->category_id): ?> selected <?php endif; ?> value="<?php echo e($category->id); ?>"><?php echo e($category->title); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div> 
            <div class="form-group">
                <label for="title">Наименование</label>
                <input type="text" class="form-control" name="title" id="title" value="<?php echo e($news->title); ?>">
            </div>
            <div class="form-group">
              <label for="autor">Автор</label>
              <input type="text" class="form-control" name="author" id="author" value="<?php echo e($news->author); ?>">
            </div>
            <div class="form-group">
              <label for="status">Статус</label>
              <select name="status" for="form-control" id="status">
                <option <?php if($news->status === 'DRAFT'): ?> selected <?php endif; ?>>DRAFT</option>
                <option <?php if($news->status === 'BLOCKED'): ?> selected <?php endif; ?>>BLOCKED</option>
                <option <?php if($news->status === 'PUBLISHED'): ?> selected <?php endif; ?>>PUBLISHED</option>
              </select>
            </div>
            <div class="form-group">
              <label for="description">Описание</label>
              <textarea type="text" class="form-control" name="description" id="description" ><?php echo e($news->description); ?></textarea>
            </div>
            <div class="form-group">
              <label for="description">Категория</label>
              <textarea type="number" class="form-control" name="category_id" id="description" ><?php echo e($news->category_id); ?></textarea>
            </div>
            <br>
            <button type="submit" class="btn btn-success">Сохранить</button>
        </form>
      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layosts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Progect\GB\resources\views/admin/news/edit.blade.php ENDPATH**/ ?>