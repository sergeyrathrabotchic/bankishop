<form action="#" method="post">
    <p>Введите имя: <br><input type="text" name="login" required/></p>
    <br>
    <p>Введите email: <br><input type="email" name="email"  required/>
    </p>
    <br>
    <p><input type="checkbox"> Запомнить меня</p>
    <input type="submit"  value="Отправить" > 
</form>