<form action="#" method="post">
    <p>Укажите новость: <br><input type="text" required/></p>
    <br>   
    <p>Подробно описашите новости: </p>
    <textarea></textarea>
    <p>Кратко описашите новости: <br><input type="text"  required/>
    </p>
    <br>
    <input type="submit"  value="Отправить" > 
</form>